### Hexlet tests and linter status:
[![Actions Status](https://github.com/rssolgaleo/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/rssolgaleo/python-project-50/actions)

# Вычислитель отличий

Вычислитель отличий – это программа, которая определяет разницу между двумя структурами данных.

## Демонстрация
* [Сравнение плоских файлов](https://asciinema.org/a/XW1NuljsLBOzPnhVOYS0fjl1S)

---

# Difference Finder

Difference Finder is a program that identifies the differences between two data structures.

## Demonstration
* [Comparison of flat files](https://asciinema.org/a/XW1NuljsLBOzPnhVOYS0fjl1S)
